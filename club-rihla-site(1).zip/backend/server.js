require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET;
const BOOTSTRAP_USERNAME = process.env.ADMIN_USERNAME;
const BOOTSTRAP_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;
const PORT = process.env.PORT || 3000;

if (!JWT_SECRET) {
  console.error(
    "ERREUR : il manque JWT_SECRET dans votre fichier .env.\n" +
    "Voir .env.example."
  );
  process.exit(1);
}

// Au premier démarrage (aucun admin dans la base), on crée le tout premier
// compte admin à partir des variables d'environnement ADMIN_USERNAME /
// ADMIN_PASSWORD_HASH. Une fois qu'il existe, les admins suivants se créent
// depuis le panneau admin lui-même (pas besoin de retoucher les variables
// d'environnement à chaque fois).
(function bootstrapFirstAdmin() {
  const data = db.read();
  if (data.admins.length === 0) {
    if (!BOOTSTRAP_USERNAME || !BOOTSTRAP_PASSWORD_HASH) {
      console.error(
        "ERREUR : aucun admin n'existe encore et ADMIN_USERNAME / ADMIN_PASSWORD_HASH " +
        "ne sont pas définis dans .env. Voir .env.example pour créer le premier admin."
      );
      process.exit(1);
    }
    data.admins.push({ username: BOOTSTRAP_USERNAME, passwordHash: BOOTSTRAP_PASSWORD_HASH });
    db.write(data);
    console.log(`Premier admin créé : ${BOOTSTRAP_USERNAME}`);
  }
})();

// ---------- Middleware d'authentification admin ----------
function requireAdmin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'unauthorized' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.adminUsername = payload.username;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'unauthorized' });
  }
}

// ---------- Routes publiques ----------

// Liste des voyages, sans exposer de détails internes
app.get('/api/trips', (req, res) => {
  const data = db.read();
  const trips = data.trips.map(t => ({
    id: t.id,
    destFr: t.destFr,
    destAr: t.destAr,
    date: t.date,
    price: t.price,
    totalSeats: t.totalSeats,
    remainingSeats: Math.max(0, t.totalSeats - t.bookedSeats)
  }));
  res.json(trips);
});

// Créer une demande de réservation (vérifie et réserve les places de façon atomique)
app.post('/api/bookings', async (req, res) => {
  const { tripId, name, phone, seats } = req.body;
  const seatsNum = parseInt(seats, 10);

  if (!tripId || !name || !phone || !seatsNum || seatsNum < 1) {
    return res.status(400).json({ error: 'invalid_input' });
  }

  const result = await db.transaction((data) => {
    const trip = data.trips.find(t => t.id === tripId);
    if (!trip) return { ok: false, error: 'trip_not_found' };

    const remaining = trip.totalSeats - trip.bookedSeats;
    if (remaining <= 0) return { ok: false, error: 'full' };
    if (seatsNum > remaining) return { ok: false, error: 'not_enough_seats', remaining };

    trip.bookedSeats += seatsNum;
    const request = {
      id: 'r_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      tripId,
      tripDestFr: trip.destFr,
      tripDestAr: trip.destAr,
      name: String(name).slice(0, 120),
      phone: String(phone).slice(0, 40),
      seats: seatsNum,
      timestamp: new Date().toISOString()
    };
    data.requests.push(request);
    return { ok: true, request };
  });

  if (!result.ok) {
    const status = result.error === 'trip_not_found' ? 404 : 409;
    return res.status(status).json(result);
  }
  res.status(201).json(result.request);
});

// ---------- Auth admin ----------
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'invalid_input' });

  const data = db.read();
  const admin = data.admins.find(a => a.username === username);
  if (!admin) return res.status(401).json({ error: 'wrong_credentials' });

  const match = await bcrypt.compare(password, admin.passwordHash);
  if (!match) return res.status(401).json({ error: 'wrong_credentials' });

  const token = jwt.sign({ role: 'admin', username }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, username });
});

// ---------- Gestion des admins (protégé — un admin connecté peut en gérer d'autres) ----------

app.get('/api/admin/admins', requireAdmin, (req, res) => {
  const data = db.read();
  res.json(data.admins.map(a => ({ username: a.username })));
});

app.post('/api/admin/admins', requireAdmin, async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password || password.length < 4) {
    return res.status(400).json({ error: 'invalid_input' });
  }
  const result = await db.transaction(async (data) => {
    if (data.admins.some(a => a.username === username)) {
      return { ok: false, error: 'username_taken' };
    }
    const passwordHash = await bcrypt.hash(password, 10);
    data.admins.push({ username: String(username).slice(0, 60), passwordHash });
    return { ok: true };
  });
  if (!result.ok) return res.status(409).json(result);
  res.status(201).json({ username });
});

app.delete('/api/admin/admins/:username', requireAdmin, async (req, res) => {
  const result = await db.transaction((data) => {
    if (data.admins.length <= 1) {
      return { ok: false, error: 'last_admin' };
    }
    const before = data.admins.length;
    data.admins = data.admins.filter(a => a.username !== req.params.username);
    if (data.admins.length === before) return { ok: false, error: 'not_found' };
    return { ok: true };
  });
  if (!result.ok) {
    const status = result.error === 'last_admin' ? 409 : 404;
    return res.status(status).json(result);
  }
  res.status(204).end();
});

// ---------- Routes admin protégées ----------

app.get('/api/admin/requests', requireAdmin, (req, res) => {
  const data = db.read();
  res.json(data.requests.slice().reverse());
});

app.post('/api/admin/trips', requireAdmin, async (req, res) => {
  const { destFr, destAr, date, price, totalSeats } = req.body;
  if (!destFr || !date || !totalSeats) return res.status(400).json({ error: 'invalid_input' });

  const trip = await db.transaction((data) => {
    const newTrip = {
      id: 't_' + Date.now(),
      destFr: String(destFr).slice(0, 120),
      destAr: String(destAr || '').slice(0, 120),
      date,
      price: parseInt(price, 10) || 0,
      totalSeats: parseInt(totalSeats, 10),
      bookedSeats: 0
    };
    data.trips.push(newTrip);
    return newTrip;
  });
  res.status(201).json(trip);
});

app.put('/api/admin/trips/:id', requireAdmin, async (req, res) => {
  const { destFr, destAr, date, price, totalSeats } = req.body;
  const result = await db.transaction((data) => {
    const trip = data.trips.find(t => t.id === req.params.id);
    if (!trip) return { ok: false };
    if (destFr !== undefined) trip.destFr = String(destFr).slice(0, 120);
    if (destAr !== undefined) trip.destAr = String(destAr).slice(0, 120);
    if (date !== undefined) trip.date = date;
    if (price !== undefined) trip.price = parseInt(price, 10) || 0;
    if (totalSeats !== undefined) trip.totalSeats = parseInt(totalSeats, 10);
    return { ok: true, trip };
  });
  if (!result.ok) return res.status(404).json({ error: 'trip_not_found' });
  res.json(result.trip);
});

app.delete('/api/admin/trips/:id', requireAdmin, async (req, res) => {
  await db.transaction((data) => {
    data.trips = data.trips.filter(t => t.id !== req.params.id);
  });
  res.status(204).end();
});

// ---------- Fichiers statiques (frontend) ----------
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Club Rihla backend en écoute sur http://localhost:${PORT}`);
});
